Meeting Summary:

**Meeting Summary: Project Sync Meeting (10:02 AM)**

**Key Points:**
- Anna provided an update on the AI chatbot project.
- Minh reported that the backend processing of intents is complete and that the API is currently being tested.
- Trang mentioned encountering some display errors with chatbot suggestions on the frontend, which will be fixed today.

**Decisions:**
- All team members are to update their progress on Jira by the end of the day.
- Huy will be asked to grant Trang additional access from DevOps.

**Action Items:**
1. Minh to continue testing the API.
2. Trang to resolve frontend display errors by the end of the day.
3. Anna to request Huy for additional access for Trang.
4. Prepare a demo version of the chatbot by next Monday.
Meeting Summary:

**Meeting Summary: Sales to CS Handoff**

**Key Points:**
- Sara confirmed the closure of a deal with NovaTech for 50 seats.
- Onboarding for NovaTech is scheduled for this Friday.
- Ken will handle the setup of the workspace and Single Sign-On (SSO).
- NovaTech has specific requirements: a Vietnamese user interface and a weekly usage report.

**Decisions:**
- Proceed with onboarding NovaTech on the scheduled date.
- Implement the requested customizations for the Vietnamese UI and usage report.

**Action Items:**
1. Ken to set up the workspace and SSO for NovaTech.
2. Mai to create a template for the weekly usage report and translate key strings into Vietnamese by the end of the day (EOD).
Meeting Summary:

**Meeting Summary: Incident Postmortem**

**Date/Time:** 09:00 AM
**Duration of Outage:** 42 minutes
**Lead:** [Name not provided]

**Key Points:**
- The outage was caused by Redis memory pressure.
- The root cause identified was a missing eviction policy on the new Redis cluster.

**Decisions Made:**
- Implement the allkeys-lru eviction policy.
- Set up alerts for when memory usage reaches 70%.
- Conduct a chaos test for Redis failover.

**Action Items:**
- **Ops:** Set up alerts for memory usage (Due by Friday).
- **Dev:** Enable the allkeys-lru eviction policy (Due by Friday).
- **QA:** Develop and execute a chaos test for Redis failover (Due by Friday).

**Next Steps:** Ensure all action items are completed by the deadline.
Meeting Summary:

**Meeting Summary: Q4 Product Planning**

**Key Points:**
- The primary goal is to ship the "Smart Summaries" feature by December 10.
- Engineering team requires 2 weeks to refactor the ingest pipeline.
- Design team is set to deliver final mockups by October 25.
- There is a risk regarding third-party transcription accuracy being less than 85% for accented Vietnamese.

**Decisions:**
- The team will use an internal model as a fallback for low-confidence transcription segments.

**Action Items:**
1. Engineering team to complete the refactoring of the ingest pipeline within 2 weeks.
2. Design team to finalize and deliver mockups by October 25.
3. Monitor and prepare for potential issues with third-party transcription accuracy.
Meeting Summary:

**Meeting Summary: HR Policy Update**

**Key Points:**
- Introduction of a new Work From Home (WFH) policy allowing employees to work up to 3 days per week, effective November 1.
- Mandatory security training for all employees to be completed by October 28.

**Decisions:**
- Implementation of the new WFH policy.
- Requirement for all employees to complete security training by the specified deadline.

**Action Items:**
- IT will send out enrollment links for the security training.
- Managers are responsible for tracking the completion of the training.
- Employees with questions are directed to email hr@company.com.