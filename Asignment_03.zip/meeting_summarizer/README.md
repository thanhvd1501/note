# AI-Powered Meeting Summarizer (Azure OpenAI)

This project implements an AI-powered meeting summarizer using the **Azure OpenAI API**.
It reads meeting transcripts and produces concise, structured summaries.

## How to Run

1. Install dependencies:
   ```bash
   pip install openai python-dotenv
   ```

2. Set environment variables (or create a `.env` file in this folder):
   - `AZURE_OPENAI_ENDPOINT` = your Azure OpenAI endpoint (e.g., https://YOUR-RESOURCE.openai.azure.com/)
   - `AZURE_OPENAI_API_KEY` = your Azure key
   - `AZURE_DEPLOYMENT_NAME` = your deployed model name (e.g., gpt-4o-mini)

3. Run:
   ```bash
   python main.py
   ```

The script uses a **dummy input list** of sample transcripts located in `meeting_summarizer/transcripts/`

Summaries will be printed to the console.

## Files
- `main.py` — single-file implementation with clear comments.
- `transcripts/` — 5 sample transcripts.
