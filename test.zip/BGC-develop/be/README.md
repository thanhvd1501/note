# Overview

## Description

A platform to book tables to participate in boss games

### System Architecture

Overview of the application architecture:

![System-Architecture](./docu/.img/architecture-overview.png)

## Getting Started

`Realease version: 0.0.1`

### Dependencies

- JDK 21
- Spring Boot 3.4.2
- Securing using Spring OAuth2
- Lombok
- Log4j2

### Package structure

- `config:` contains the config of the application (such as: security config, task executors config,
  keycloak config, etc.)
- `controller:` define all the RestAPIs that will be provided to outside
- `service:` where the business logic is implemented
- `entity:` the objects mapped with database table
- `dto:` the response objects used to return to client
- `exception:` the customization exception

### Installing

#### 1. Setting up local development environment

- Install JDK 21
- Install Apache Maven 4.0.0 (or higher)

#### 2. Build and run the application

- Go to the project directory and run the command

```text
mvn clean package
```

- After building completed, go to `/target` directory then run the command

```text
java -jar quickreserve-0.0.1.jar
```

## Responsible Teams

| **Role**                 | **Who**                                 |
|--------------------------|-----------------------------------------|
| Software Solution, QA/BA | Thanh Vu (vuducthanh0115@gmail.com.com) |
| Software Solution, QA/BA | Hung Ngo (.com)                         |
| Software Solution, QA/BA | Dong Luu (.com)                         |
| Software Solution, QA/BA | Kien Ngo (.com)                         |
