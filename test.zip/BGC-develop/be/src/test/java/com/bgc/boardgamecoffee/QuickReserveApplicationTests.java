package com.bgc.boardgamecoffee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuickReserveApplicationTests {

  @Test
  void contextLoads() {
  }

}
