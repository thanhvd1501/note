package com.bgc.boardgamecoffee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoardGameCoffeeApplication {

  public static void main(String[] args) {
    SpringApplication.run(BoardGameCoffeeApplication.class, args);
  }

}
