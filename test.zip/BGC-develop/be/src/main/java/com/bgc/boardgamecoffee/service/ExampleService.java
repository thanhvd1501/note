package com.bgc.boardgamecoffee.service;

public interface ExampleService {

}
