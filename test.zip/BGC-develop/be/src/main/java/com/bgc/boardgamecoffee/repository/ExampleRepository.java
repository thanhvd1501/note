package com.bgc.boardgamecoffee.repository;

import com.bgc.boardgamecoffee.entity.Example;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Example repository
 *
 * @author Thanh Vu
 */
@Repository
public interface ExampleRepository extends JpaRepository<Example, Long> {

}
