package com.bgc.boardgamecoffee.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

/**
 * Test controller ...
 *
 * @author Thanh Vu
 */
@RestController
public class TestController implements TestResource {

  @Override
  public ResponseEntity<String> test() {
    return ResponseEntity.ok("Hello World");
  }
}
