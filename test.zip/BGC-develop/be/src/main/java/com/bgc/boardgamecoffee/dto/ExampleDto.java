package com.bgc.boardgamecoffee.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ExampleDto {

  private String id;

  private String email;

  private String name;

  private String organization;

  private String role;

  private String password;
}
