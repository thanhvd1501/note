package com.bgc.boardgamecoffee.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BaseErrorDto {

  @JsonProperty("timestamp")
  protected Date timestamp;

  @JsonProperty("error_message")
  protected String errorMessage;
}
