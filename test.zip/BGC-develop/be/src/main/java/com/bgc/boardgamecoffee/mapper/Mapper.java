package com.bgc.boardgamecoffee.mapper;

import java.util.List;

/**
 * @param <E> Entity type
 * @param <D> Data transfer object type
 */
public interface Mapper<E, D> {

  /**
   * Convert entity to dto
   *
   * @param e E
   * @return D
   */
  D toDto(E e);

  /**
   * Convert list of entity to list of DTO
   *
   * @param eList List<E>
   * @return List<D>
   */
  List<D> toDtoList(List<E> eList);

  /**
   * @return Class<D>
   */
  Class<D> getDtoClass();
}
