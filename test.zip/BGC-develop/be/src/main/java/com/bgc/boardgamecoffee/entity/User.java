package com.bgc.boardgamecoffee.entity;


import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User {
    private String id;
    private String username;
    private String email;
    private String name;
    private String picture;
    private String type;
    private String role;
}
