package com.bgc.boardgamecoffee.constant;

import java.util.Map;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class SecurityConstant {

  public static final Map<String, Integer> ORIGIN_ACCESS_PERMISSION = Map.of(
      "admin", 1001,
      "competition", 1002,
      "volunteer", 1003,
      "webpage", 1004
  );

  public static final String SUPER_ADMIN = "SUPER_ADMIN";

  public static final String MASTER_AREA = "master";

  public static final String ANY = "*";

  // --- Start: List of the security permissions (pre-defined in DB)---

  public static final String PMS_SUPER_ADMIN = "100";

  public static final String PMS_IAM_ADMIN = "200";

  public static final String PMS_COMPETITION_ADMIN = "300";

  public static final String PMS_VOLUNTEER_ADMIN = "600";

  // --- End: List of the security permissions ---

  public static final String HEADER_FORWARDED_ADDRESS = "X-Forwarded-For";

  public static final String HEADER_ORIGIN = "x-origin";

  public static final String AUTH_PARAM_CLIENT_IP = "AUTH_PARAM_CLIENT_IP";

  public static final String AUTH_PARAM_ORIGIN = "AUTH_PARAM_ORIGIN";

  public static final String TOKEN_CLAIM_REFRESH_VALUE = "REFRESH";

  public static final String PARAM_CLIENT_ID = "client_id";

  public static final String PARAM_CLIENT_SECRET = "client_secret";

  public static final String TOKEN_CLAIM_TYPE = "typ";

  public static final String TOKEN_CLAIM_SCOPE = "scope";

  public static final String TOKEN_CLAIM_SESSION_ID = "sid";

  public static final String TOKEN_CLAIM_CLIENT_ID = "cli";

  public static final String TOKEN_CLAIM_USER_ID = "uid";

  public static final String TOKEN_CLAIM_USERNAME = "username";

  public static final String TOKEN_CLAIM_EMAIL = "email";

  public static final String TOKEN_CLAIM_ACCESSIBLE_RESOURCE_AREA = "ara";

  public static final String TOKEN_CLAIM_ROLE = "role";

  public static final String TOKEN_CLAIM_PERMISSION = "pms";

  public static final String TOKEN_CLAIM_USER_FULL_NAME = "name";
}
