package com.bgc.boardgamecoffee.mapper;

import com.bgc.boardgamecoffee.dto.ExampleDto;
import com.bgc.boardgamecoffee.entity.Example;
import java.util.List;
import org.springframework.stereotype.Component;

@Component
public class ExampleMapper extends AbstractMapper<Example, ExampleDto> {

  @Override
  public Class<ExampleDto> getDtoClass() {
    return ExampleDto.class;
  }

  @Override
  public ExampleDto toDto(Example example) {
    return super.toDto(example);
  }

  @Override
  public List<ExampleDto> toDtoList(List<Example> entities) {
    return super.toDtoList(entities);
  }
}
