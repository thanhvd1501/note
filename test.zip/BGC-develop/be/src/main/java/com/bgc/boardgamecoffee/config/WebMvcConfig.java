package com.bgc.boardgamecoffee.config;

import com.bgc.boardgamecoffee.constant.SecurityConstant;
import java.util.Arrays;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.http.HttpHeaders;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

@Configuration
public class WebMvcConfig {

  private static final String ALLOWED_ORIGINS = "*";

  private static final String[] ALLOWED_METHODS = {"OPTIONS", "GET", "POST", "PUT", "DELETE",
      "PATCH", "HEAD"};

  private static final String[] ALLOWED_HEADERS = {
      HttpHeaders.CONTENT_TYPE,
      HttpHeaders.ACCEPT_LANGUAGE,
      HttpHeaders.AUTHORIZATION,
      HttpHeaders.ORIGIN,
      SecurityConstant.HEADER_FORWARDED_ADDRESS,
      SecurityConstant.HEADER_ORIGIN
  };

  @Bean
  public FilterRegistrationBean<CorsFilter> customCorsFilter() {
    UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
    CorsConfiguration config = new CorsConfiguration();
    config.setAllowedMethods(Arrays.asList(ALLOWED_METHODS));
    config.setAllowedHeaders(Arrays.asList(ALLOWED_HEADERS));
    config.addAllowedOrigin(ALLOWED_ORIGINS);
    source.registerCorsConfiguration("/**", config);
    FilterRegistrationBean<CorsFilter> bean = new FilterRegistrationBean<>(new CorsFilter(source));

    bean.setOrder(Ordered.HIGHEST_PRECEDENCE);
    return bean;
  }
}
