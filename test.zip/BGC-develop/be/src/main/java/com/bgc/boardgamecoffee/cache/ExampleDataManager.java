package com.bgc.boardgamecoffee.cache;

public interface ExampleDataManager {

}
