package com.bgc.boardgamecoffee.exception;

import java.io.Serial;

/**
 * @author Thanh Vu
 */
public class InternalServerException extends Exception {

  @Serial
  private static final long serialVersionUID = 1L;

  public InternalServerException(String msg) {
    super(msg);
  }

  public InternalServerException(String msg, Throwable t) {
    super(msg, t);
  }
}
