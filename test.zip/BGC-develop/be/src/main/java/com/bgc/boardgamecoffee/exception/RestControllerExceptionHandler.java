package com.bgc.boardgamecoffee.exception;

import com.bgc.boardgamecoffee.dto.BaseErrorDto;
import java.util.Date;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * @author Thanh Vu
 */
@ControllerAdvice
@Slf4j
public class RestControllerExceptionHandler extends ResponseEntityExceptionHandler {

  /**
   * Handle the Internal Server Error
   *
   * @param e Exception
   * @return ResponseEntity<Object>
   */
  @ExceptionHandler(Exception.class)
  @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
  public ResponseEntity<Object> handleException(Exception e) {
    log.error("", e);
    BaseErrorDto error = BaseErrorDto.builder()
        .timestamp(new Date())
        .errorMessage("Server Error")
        .build();
    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
  }
}
