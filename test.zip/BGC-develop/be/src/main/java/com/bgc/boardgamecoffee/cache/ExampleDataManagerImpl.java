package com.bgc.boardgamecoffee.cache;

public class ExampleDataManagerImpl {

}
