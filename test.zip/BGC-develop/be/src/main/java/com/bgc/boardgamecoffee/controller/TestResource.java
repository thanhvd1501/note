package com.bgc.boardgamecoffee.controller;

import io.swagger.v3.oas.annotations.Operation;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping(TestResource.TEST_RESOURCE)
public interface TestResource {

  String TEST_RESOURCE = "test";

  @Operation(summary = "Test")
  @GetMapping
  ResponseEntity<String> test();
}
