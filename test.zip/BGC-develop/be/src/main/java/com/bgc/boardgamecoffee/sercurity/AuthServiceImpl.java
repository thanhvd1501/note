package com.bgc.boardgamecoffee.sercurity;

import com.bgc.boardgamecoffee.dto.auth.AuthRequest;
import com.bgc.boardgamecoffee.entity.User;
import com.bgc.boardgamecoffee.util.JwtTokenUtil;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.gson.GsonFactory;
import com.restfb.DefaultFacebookClient;
import com.restfb.FacebookClient;
import com.restfb.Parameter;
import com.restfb.Version;
import com.restfb.exception.FacebookOAuthException;
import com.restfb.json.JsonObject;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Collections;

@RequiredArgsConstructor
@Service
public class AuthServiceImpl implements AuthService {

    private final JwtTokenUtil jwtTokenUtil;
    private static final JsonFactory JSON_FACTORY = GsonFactory.getDefaultInstance();
    @Value("${idp.google-client-id}")
    private String googleClientId;

    public String authenticateWithGoogle(AuthRequest request) throws Exception {
        GoogleIdTokenVerifier verifier = new GoogleIdTokenVerifier.Builder(GoogleNetHttpTransport.newTrustedTransport(), JSON_FACTORY)
                .setAudience(Collections.singletonList(googleClientId))
                .build();

        GoogleIdToken idToken = verifier.verify(request.getIdToken());
        if (idToken == null) {
            throw new Exception("Unauthorized");
        }

        GoogleIdToken.Payload payload = idToken.getPayload();
        User user = User.builder()
                .name((String)payload.get("name"))
                .email(payload.getEmail())
                .picture((String)payload.get("picture"))
                .role("user")
                .build();

        return jwtTokenUtil.generateToken(user);
    }

    @Override
    public String authenticateWithFacebook(AuthRequest authRequest) throws Exception {
        try {
            FacebookClient facebookClient = new DefaultFacebookClient(authRequest.getAccessToken(), Version.LATEST);
            JsonObject data = facebookClient.fetchObject("me", JsonObject.class, Parameter.with("fields", "id,name,email,picture"));

            User user = User.builder()
                    .name(data.getString("name", ""))
                    .email(data.getString("email", ""))
                    .picture(data.get("picture")
                            .asObject().get("data")
                            .asObject().getString("url", "")
                            )
                    .role("user")
                    .build();

            return jwtTokenUtil.generateToken(user);
        } catch (FacebookOAuthException e) {
            throw new Exception("Unauthorized");
        }
    }

}
