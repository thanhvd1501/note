package com.bgc.boardgamecoffee.service;

/**
 * Example service
 *
 * @author Thanh Vu
 */
//@Service
public class ExampleServiceImpl implements ExampleService {

}
