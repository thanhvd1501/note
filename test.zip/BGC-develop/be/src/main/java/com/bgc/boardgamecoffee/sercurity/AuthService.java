package com.bgc.boardgamecoffee.sercurity;

import com.bgc.boardgamecoffee.dto.auth.AuthRequest;

public interface AuthService {

    public String authenticateWithGoogle(AuthRequest authRequest) throws Exception;
    public String authenticateWithFacebook(AuthRequest authRequest) throws Exception;

}
