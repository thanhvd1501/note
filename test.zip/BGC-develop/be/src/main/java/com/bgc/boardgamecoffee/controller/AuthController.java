package com.bgc.boardgamecoffee.controller;

import com.bgc.boardgamecoffee.dto.auth.AuthRequest;
import com.bgc.boardgamecoffee.dto.auth.AuthResponse;
import com.bgc.boardgamecoffee.sercurity.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RequiredArgsConstructor
@RestController
@RequestMapping("auth")
public class AuthController {

    private final AuthService authService;

    @PostMapping("/google")
    public AuthResponse authenticateWithGoogle(@RequestBody AuthRequest request) throws Exception {
        return new AuthResponse(authService.authenticateWithGoogle(request));
    }

    @PostMapping("/facebook")
    public AuthResponse authenticateWithFacebook(@RequestBody AuthRequest request) throws Exception {
       return new AuthResponse(authService.authenticateWithFacebook(request));
    }

}
