import { auth } from "@/auth"
 
export default auth(async (req) => {
  const session = await auth();
  if(!!session?.user) {
    console.log('auth')
  } else {
    console.log('not auth')
  }
})

export const config = {
  matcher: '/:path*',
}
