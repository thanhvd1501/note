import { auth } from "@/auth";
import FacebookSignIn from "@/components/sign-in-facebook";
import GoogleSignIn from "@/components/sign-in-google";
import SignOut from "@/components/sign-out";

export default async function Home() {

  const session = await auth();
  
  const data = await fetch('http://localhost:8080/api/v1/test', {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      'Authentication': `Bear ${session?.accessToken}`
    }
  })

  return (
    <div>
      {!!session?.user ? (
        <SignOut />
      ) : (
        <>
          <GoogleSignIn />
          <FacebookSignIn />
        </>
      )}
      Hello BGC<br/>
      {await data.text()}
    </div>
  );
}
