import NextAuth from "next-auth"
import Facebook from "next-auth/providers/facebook"
import Google from "next-auth/providers/google"
import { API_BASE_URL } from "./lib/config";
import { extractRoleFromToken } from "./lib/utils";
 
export const { handlers, signIn, signOut, auth } = NextAuth({
  providers: [Google, Facebook],
  callbacks: {
    async jwt({ token, account }) {
      if (account) {
        if(account.provider === 'google') {
          const resp = await fetch(`${API_BASE_URL}/api/v1/auth/google`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              idToken: account.id_token
            })
          });

          if(resp.ok) {
            const data = await resp.json();
            token.accessToken = data.token
          } 
        } else if(account.provider === 'facebook') {
          const resp = await fetch(`${API_BASE_URL}/api/v1/auth/facebook`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              accessToken: account.access_token
            })
          });

          if(resp.ok) {
            const data = await resp.json();
            token.accessToken = data.token
          }
        }
      }

      return token
    },
    async session({ session, token }) {
      session.accessToken = token.accessToken as string
      session.user.role = extractRoleFromToken(session.accessToken)
      return session
    },
  },
})
