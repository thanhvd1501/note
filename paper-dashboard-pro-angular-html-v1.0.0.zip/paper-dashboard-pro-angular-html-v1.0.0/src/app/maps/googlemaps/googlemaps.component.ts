import { Component, OnInit } from '@angular/core';

declare var google: any;
declare var $: any;

@Component({
    moduleId: module.id,
    selector: 'vector-maps-cmp',
    templateUrl: './googlemaps.component.html'
})

export class GoogleMapsComponent implements OnInit{

    ngOnInit(){
    

    }
}
