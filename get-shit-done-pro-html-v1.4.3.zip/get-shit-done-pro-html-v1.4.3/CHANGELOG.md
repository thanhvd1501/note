## V1.0 22.10.2014
### Original Release

## V1.1 11.11.2014
### Changes in coder package
    - added bootstrap 3.3.0 support
    - added LESS Files
    - fix dropdown navbar divider gray color insider colored navbars
    - fix navbar collapse issue when window is resizing

## V1.2 09.12.2014
### Changes in coder package
    - added 6 page examples (Home, Ecommerce, About Us, Contact Us, Pricing and Blog)
    - small fix for dropdown with one item

## V1.3 27.01.2015
### Changes in Coder Package
    - added 2 page examples (Product Page, Blog Post)
    - added page with all components
    - update stroke icons, now there are 200+ icons
    - fix .btn class in navbar
    - added “Flexisel” js library for better images carousel

## V1.3.1 26.05.2015
### Bugfixing
    - input-group-addons class fix focus
    - input-group button fix
    - fix issue on dropdown select

## V1.3.2 09.06.2015
### Bugfixing
    - disabled button fix style
    - input radio fix for disabled inputs

## V1.4 03.10.2015
### Major Updates on third party plugins
    - update Font Awesome to 4.4.0
    - update Bootstrap to 3.3.5 (Bootstrap 4 is work in progress)
    - update chartist.js to 0.9.4
    - added support for typekit
    - replace images with thumbs, reduce the size of kit archive with 17MB
    - added retina.js, library who check if there are retina images on server
    - other small changes and fixes

## V1.4.1 23.11.2015
### Minor fix
    - Mobile Sidebar can be tested on Desktop too, not only on tablet/mobile

## V1.4.2 17.12.2015
### Off Canvas Menu Feature (SidebarMenu),Plugin Updates and Issue Fixes
    - added Sidebar Menu with a simple class on navbar “navbar-burger”
    - update to Bootstrap-Select v1.8.1
    - fix bug with default Bootstrap Panels
    - fix bug when you have long text 18+ characters in dropdowns with icons
    - added auto-close after 5 seconds for notifications
    - fix bootstrap select with multiple options checks
    - fix alignment issue in inputs with Font Awesome Icons

## V1.4.3 29.01.2016
### Bugfixing
    - added autocomplete for tags
    - navbar-inverse issue with active links
    - caret issue on sidebar for iPhone 5
