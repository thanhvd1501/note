# Meeting Summarizer

This project summarizes meeting transcripts using Azure OpenAI.

## Prerequisites

- Python 3.8+
- [pip](https://pip.pypa.io/en/stable/)
- Azure OpenAI credentials (see `.env`)

## Setup

1. **Install dependencies**
   ```sh
   pip install openai python-dotenv
   ```

2. **Configure environment variables**  
   Run command `cp .env.example .env`  
   Edit `meeting_summarizer/.env` with your Azure OpenAI credentials:
   ```
   AZURE_DEPLOYMENT_NAME="your-deployment-name"
   AZURE_OPENAI_ENDPOINT="your-endpoint-url"
   AZURE_OPENAI_API_KEY="your-api-key"
   ```

3. **Add transcripts**  
   Place your `.txt` files in `meeting_summarizer/transcripts/`.

## Run

From the `meeting_summarizer` directory, run:

```sh
python main.py
```

Summaries will be printed to the console.
