import { Component, OnInit } from '@angular/core';


@Component({
    selector: 'app-pricing-cmp',
    templateUrl: './pricing.component.html'
})

export class PricingComponent implements OnInit {
    test: Date = new Date();
    ngOnInit() {
    }
}
