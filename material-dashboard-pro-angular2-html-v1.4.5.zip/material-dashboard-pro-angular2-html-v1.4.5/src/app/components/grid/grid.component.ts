import { Component } from '@angular/core';

@Component({
    selector: 'app-grid-cmp',
    templateUrl: 'grid.component.html'
})

export class GridSystemComponent {}
